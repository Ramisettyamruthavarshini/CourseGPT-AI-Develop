import LessonGenerator from '../components/LessonGenerator';

export default function Home() {
  return (
    <div>
      <h1>CourseGPT - Lesson Generator</h1>
      <LessonGenerator />
    </div>
  );
}