# CourseGPT Prototype

This is a prototype of a course authoring tool designed to simulate AI-assisted lesson creation.

## Features

- Topic input form
- Simulated AI lesson generator
- Editable lesson components

## How to Run

1. Install dependencies:
```
npm install
```

2. Start the development server:
```
npm run dev
```

3. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Notes

- Built using Next.js
- Simulated AI response for demonstration
- No actual API integration in this version