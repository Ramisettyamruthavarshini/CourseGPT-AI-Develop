import { useState } from 'react';

export default function LessonGenerator() {
  const [topic, setTopic] = useState('');
  const [lesson, setLesson] = useState(null);

  const generateLesson = () => {
    setLesson({
      title: `Understanding ${topic}`,
      description: `An engaging lesson on the topic of ${topic}.`,
      outcomes: ['Explain the concept', 'Identify key components', 'Apply knowledge in examples'],
      activities: ['Group discussion', 'Quiz', 'Practical exercise']
    });
  };

  return (
    <div>
      <input 
        type="text" 
        value={topic} 
        onChange={e => setTopic(e.target.value)} 
        placeholder="Enter topic..." 
      />
      <button onClick={generateLesson}>Generate Lesson</button>

      {lesson && (
        <div style={{ marginTop: '20px' }}>
          <h2>{lesson.title}</h2>
          <p>{lesson.description}</p>
          <h3>Outcomes:</h3>
          <ul>{lesson.outcomes.map((o, i) => <li key={i}>{o}</li>)}</ul>
          <h3>Activities:</h3>
          <ul>{lesson.activities.map((a, i) => <li key={i}>{a}</li>)}</ul>
        </div>
      )}
    </div>
  );
}